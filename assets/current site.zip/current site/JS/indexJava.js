
window.sr = ScrollReveal({ reset: true });;
sr.reveal('.cps');
sr.reveal('.idm');
sr.reveal('.ccim');
sr.reveal('.fizz');
sr.reveal('.rec');